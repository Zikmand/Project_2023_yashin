<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панацея</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <style>
       body {
      background-color: #f8f9fa;
      margin: 0;
      padding: 0;
    }
    #logoButton {
      cursor: pointer;
    }
    input{
      margin-bottom:10px;
    }
    button{
      margin-top: 10px;
    }
      
    
  </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <div class="navbar-brand d-flex align-items-center">
            <img src="logo.png" alt="Logo" width="30" class="d-inline-block align-text-top">
            <a href="#" class="d-inline-block align-text-top ms-2">Панацея</a>
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php" style="font-size: 1.4em; color: black;">Главная страница</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="doctor.php" style="font-size: 1.4em; color: black;">Врачи</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php" style="font-size: 1.4em; color: black;">Вход/регистрация</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
  <h1 class="text-center">Записаться на прием</h1>
  <form> <div class="form-group"> 
    <label for="name">ФИО:</label> 
    <input type="text" class="form-control" id="name" placeholder="Введите ваше имя" required> </div> 
    <div class="form-group"> 
      <label for="phone">Номер телефона:</label> 
      <input type="tel" class="form-control" id="phone" placeholder="Введите ваш номер телефона" required> </div> 
      <div class="form-group"> 
        <label for="problem">Опишите вашу проблему:</label> <textarea class="form-control" id="problem" rows="3" required></textarea> </div> 
        <button type="submit" class="btn btn-primary">Отправить</button> 
        <a class="add" href="logout.php" align="center">Выйти из учетной записи</a></form>
<footer class="bg-light mt-5">
        <div class="container">
            <p class="text-center py-3">© 2024 ПАНАЦЕЯ. Все права защищены.</p>
        </div>
    </footer>
<!-- Add Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz4fnFO9gybBud7TlRbs/ic4AwGcFZOxg5DpPt8EgeUIgIwzjWfXQKWA3"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
        crossorigin="anonymous"></script>
</body>
</html>