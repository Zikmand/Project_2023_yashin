<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панацея</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <style>
       ul{
        font-size: 16px;
       }
       p{
        font-size: 20px;  
       }
       button{
        font-size: 16px;
       }
      
    
  </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <div class="navbar-brand d-flex align-items-center">
            <img src="logo.png" alt="Logo" width="30" class="d-inline-block align-text-top">
            <a href="#" class="d-inline-block align-text-top ms-2">Панацея</a>
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php" style="font-size: 1.4em; color: black;">Главная страница</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="doctor.php" style="font-size: 1.4em; color: black;">Врачи</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php" style="font-size: 1.4em; color: black;">Вход/регистрация</a>
                </li>
            </ul>
        </div>
    </div>
</nav>


    <!-- Content -->
    <div class="container mt-5">
    <?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT * FROM photos";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<div class="row">';
    $i = 0;
    while($row = $result->fetch_assoc()) {
        if ($i % 3 == 0) {
            echo '<div class="row">';
        }
        echo "
        <div class='col-md-4'>
            <div class='card'>
                <img src='" . $row["photo"] . "' class='card-img-top' alt='...' >
                <div class='card-body'>
                    <p class='card-text'>" . $row["description"] . "</p>
                </div>
            </div>
        </div>
        ";
        if ($i % 3 == 2) {
            echo '</div>';
        }
        $i++;
    }
    if ($i % 3 != 0) {
        echo '</div>';
    }
    echo '</div>';
} else {
    echo "0 results";
}

$conn->close();
?>

    </div>

  
    <footer class="bg-light mt-5">
        <div class="container">
            <p class="text-center py-3">© 2024 ПАНАЦЕЯ. Все права защищены.</p>
        </div>
    </footer>


    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz4fnFO9gybBud7TlRbs/ic4AwGcFZOxg5DpPt8EgeUIgIwzjWfXQKWA3"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
        crossorigin="anonymous"></script>
</body>
</html>
