<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
  die("не удалось подключиться: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  session_start();
  $_SESSION['username'] = $username;
  header('Location: form.php');
} else {
  
}

$conn->close();
?>
