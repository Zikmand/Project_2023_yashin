<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панацея</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <style>
       body {
      background-color: #f8f9fa;
      margin: 0;
      padding: 0;
    }
    #logoButton {
      cursor: pointer;
    }
    input{
      margin-bottom:10px;
    }
      
    
  </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <div class="navbar-brand d-flex align-items-center">
            <img src="logo.png" alt="Logo" width="30" class="d-inline-block align-text-top">
            <a href="#" class="d-inline-block align-text-top ms-2">Панацея</a>
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php" style="font-size: 1.4em; color: black;">Главная страница</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="doctor.php" style="font-size: 1.4em; color: black;">Врачи</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php" style="font-size: 1.4em; color: black;">Вход/регистрация</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
  <h1 class="text-center">Регистрация</h1>
  <form action="register_action.php" method="post">
  <div class="form-group">
    <label for="username">Имя пользователя:</label>
    <input type="text" class="form-control" id="username" name="username" required>
  </div>
  <div class="form-group">
    <label for="email">Электронная почта:</label>
    <input type="text" class="form-control" id="email" name="email" required>
  </div>
  <div class="form-group">
    <label for="password">Пароль:</label>
    <input type="password" class="form-control" id="password" name="password" required>
  </div>
  <div class="form-group">
    <label for="confirm-password">Подтвердите пароль:</label>
    <input type="password" class="form-control" id="confirm-password" name="confirm-password" required>
  </div>
  <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
  <p>Уже зарегистрировались?</p>
  <a href="login.php">Авторизоваться</a>
</form>
<footer class="bg-light mt-5">
        <div class="container">
            <p class="text-center py-3">© 2024 ПАНАЦЕЯ. Все права защищены.</p>
        </div>
    </footer>
<!-- Add Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz4fnFO9gybBud7TlRbs/ic4AwGcFZOxg5DpPt8EgeUIgIwzjWfXQKWA3"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
        crossorigin="anonymous"></script>
</body>
</html>